# TUGAS BESAR LOGIKA KOMPUTASIONAL (IF2121)

## NARUTO SHIPPUDEN : HINATA THE LOST GIRL
Kelompok 1 / K03 :

1. Abdul Aziz Alghifari				10118021
2. Daffa Pratama Putra 				13518033
3. Muchammad Ibnu Sidqi 			13518072
4. M. Mirza Fathan Al Arsyad		13518111
5. Stephen Thajeb	 				13518150
